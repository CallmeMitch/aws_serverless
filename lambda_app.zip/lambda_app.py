import json

print('Loading function')


def lambda_handler(event, context):
    print("message is :", event['key1'])
    message = json.dumps({'Message': event["key1"] })

    return json.loads(message)